<?php
        include_once 'session_check.php';
        include_once 'menu.php';
?>

<div class="container">
    <h2> Nouvel utilisateur </h2>
    <form id="add_user" method="post" name="add_user"  action="useraction_exec.php"> 
    <div>
      <div class="row">
        <div class="col-12 col-lg-4">
            <p>Identifiant: <input type="text" name="new_id">
        </div>
        <div class="col-12 col-lg-4">
            <p>Mot de passe : <input type="text" name="new_password"></p>
        </div>
        <div class="col-12 col-lg-4">  
            <input type= 'hidden' name='action_name' value='add_user'/>
            <p><input type="submit" value="Ajouter"></p>
        </div>
      </div>
    </div>   
    </form>
</div>   
    <div class="container" >
      <h2>Listes des utilisateurs</h2>
      <table class="table">
        <thead class="thead-dark">
          <tr>
            <th>ID</th>
            <th>Login</th>
            <th>Mots de passe</th>
            <th>Action</th>
         </thead>

<?php
      try
      {

        include_once 'bddconnect.php';        
         
         // On recupere tout le contenu de la table Membre
      $reponse = $bdd->query('SELECT id, identifiant, motdepasse FROM membre');
      
      // On affiche le resultat
      while ($donnees = $reponse->fetch())
      {
         //On affiche l'id et le nom du client en cours
         echo '<form id="supp_user" method="post" name="supp_user"  action="useraction_exec.php">';
         echo "</tr>";
         echo "<th> $donnees[id] </th>";
         echo "<th> $donnees[identifiant] </th>";
         echo "<th> $donnees[motdepasse] </th>";
          
         echo "<th>   <input type= 'hidden' name='data_id' value='$donnees[id]'/>"
                   . "<input type= 'hidden' name='action_name' value='delete_user'/> "
                   . "<input type='submit'  value='Supprimer' id=$donnees[id]></th>";
         echo "</tr>";
         echo '</form>';
     }
      $reponse->closeCursor();
      }
      catch(Exception $e)
      {
         die('Erreur : '.$e->getMessage());
      }

          
?>

        </tbody>
      </table>
      <?php       
      if (isset($_SESSION['Message']))
      {
          echo $_SESSION['Message'];
          UNSET($_SESSION['Message']);
      }?>
    </div>
