<?php
  include_once 'session_check.php';
  include_once 'bddconnect.php';  
  
  $data_form["action"]=$_POST["action_name"];
  
  IF ($data_form["action"] == "update_note")
  {
         $data["nom"]= $_POST["nom"];
         $data["prenom"]= $_POST["prenom"];
         $data["numero_commission"]= $_POST["numero_commission"];
         $data["numero_candidat"]= $_POST["numero_candidat"];
         $data["date_epreuve"]=  $_POST["date_epreuve"];
         $data["note"]= $_POST["note"];
         $data["type_epreuve"]= $_POST["type_epreuve"];
         $data["id"]= $_POST["id"];
          
      try
      {
        // assemblage de la requête sql.
         $sql ="UPDATE `epreuve` SET 
              `nom` = '".$data['nom']."',
              `prenom` = '".$data['prenom']."', 
              `numero_commission` = '".$data['numero_commission']."', 
              `numero_candidat` = '".$data['numero_candidat']."', 
              `date_epreuve` = '".$data['date_epreuve']."', 
              `note` = '".$data['note']."', 
              `type_epreuve` = '".$data['type_epreuve']."'
              WHERE `epreuve`.`id` = '".$data['id']."'";

         // On executer la requête sql
      $reponse = $bdd->exec($sql);
      
        $_SESSION["Message"]= "<label><p style='color:green'>Message : note pour l'élève numéro ".$data_form["id"]." bien modifiée. </label>";
      }
      catch(Exception $e)
      {
         die('Erreur : '.$e->getMessage());
      }
  }
  elseif ($data_form["action"] == "delete_note") {
        $data_form["eleve_id"]=$_POST['eleve_id'];
        try
      {
        // assemblage de la requête sql.
        $sql ="delete FROM `epreuve` WHERE `id` = '".$data_form["eleve_id"]."'";
        // On executer la requête sql
        $reponse = $bdd->exec($sql);
        $_SESSION["Message"]= "<label><p style='color:red'>Message : note pour l'élève numéro ".$data_form["eleve_id"]." bien supprimée. </label>";
      }
      catch(Exception $e)
      {
         die('Erreur : '.$e->getMessage());
      }
}
      
    header('Location: notemodifier_form.php');
      
      ?>