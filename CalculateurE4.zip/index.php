<?php

  session_start();
  /*
  //Quand action de déconnexion alors :
  session_destroy();
  $SESSION["ath_status"] = "deconnecte";
  */

 /* echo "Dump post   : ";
  echo var_dump($_POST);

  echo "Dump session: ";
  echo var_dump($_SESSION);*/

  //vérifie si dans le tableau des variables de session, la reference "ath_status" exsite ? (si ca existe pas, et que je fais un test "==" ca plante)
  if(isset($_SESSION["ath_status"]))
  {
    // alors on test l'etat de "ath_status"
    if( $_SESSION["ath_status"] == "connecte" )
      {
      //si on est connecté (ath_status = connecte) alors :
        if(isset($_POST["action"]))
        {
        /*
        $ath_status = $_SESSION["ath_status"];
        $page_origine = $_SESSION["page_origine"];
        $action_origine = $_SESSION["action_origine"];
        $action_souhaite = $_SESSION["action_souhaite"]; 
        $droit = $_SESSION["ath_droit"];
        */     
      // Pacours de l'utilisateur connecté :
      // gestion de la page d'origine pour atteindre la page suivante souhaité en fonction de l'action demandé.
        }
        else
        {
           include_once 'menu.php'; // proposer la page menu (si pas d'action)
        }
      }
      else
      //Si on est pas connecté (ath_status != connecte)
      {
      // On propose la connexion :
       include_once 'menu.php';
      }
  }
    else
    //Si la session est vide (donc première visite sur la page)
    {
    // On propose la connexion :
    header('Location: connexion.php');
    }
?>



