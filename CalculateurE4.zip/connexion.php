<?php

session_start();


@$login = $_POST["login"];
@$password = $_POST["password"];
@$action= $_POST["action"];
$erreur = "0";

 
if (isset($_SESSION))
	{
		if(isset($_POST["action"])) //(isset verifi si vairable existe)vérifie si on est arrivé sur cette page depuis un formulaire action
			{
			if($_POST["action"]=="connecter")
			    {
                            $login = trim($login);
                            $password = trim($password);
                            if ((strlen($login)<3) or (strlen($password))<3)
                            {$erreur= " login ou mot de passe avec minimum 3 caractères ";}
                            else {
                                try
                                {
                                  include_once 'bddconnect.php';
                                  // On recupere tout le contenu de la table Client
                                  $reponse = $bdd->prepare('SELECT count(id) FROM MEMBRE where identifiant= :identifiant and motdepasse= :motdepasse');
                                  $reponse->execute(['identifiant' => $login, 'motdepasse' => $password]); 
                                  $donnees = $reponse->fetch();
                                  $reponse->closeCursor();
                                }
                                catch(Exception $e)
                                {
                                   die('Erreur : '.$e->getMessage());
                                }
                                if ($donnees['count(id)'] > 0)
                                        {
                                                $_SESSION["ath_status"] = "connecte";
                                                $_SESSION["login"]=$login;
                                                header("location:index.php");
                                        }
                                else 
                                        {
                                                $_SESSION["ath_status"] = "failed";
                                                $erreur = "L'identifiant ou le mot de passe est incorrect";
                                        }
                            }
                            if($_POST["action"]=="deconnecter")
				{
				//Quand action de déconnexion alors :
				//session_destroy();
				//on valorise la variable ath_status de session a "deconecte"
				$_SESSION["ath_status"] = "deconnecte";
				}
                            }
			}
		else //sinon, c'est qu'on vient de l'index ou d'une url direct
			{
                            if(isset($_POST["ath_status"]))
                            {
                                if ($_SESSION["ath_status"] == "connecte") 
                                    header("location:menu.php");
                            }
                        }
	}
else
{
	$_SESSION["ath_status"] = "deconnecte";
}

        include_once 'head.php';
?>


    <body>
	 <div >
             <div class="TITRE">
                 <h1 >&nbsp;&nbsp;Outil notation épreuve E4</h1>
             </div>
                 <h3 >&nbsp;&nbsp;Conforme aux formalités d'examen du BTS SIO</h3>
            <?php
            if($erreur != "0")
            {	//popups avec message d'erreur
                echo "<label><p style='color:red'>Message :".$erreur."</label>";
            } 
            ?>
            <div class="center">
                <form method="post" action="connexion.php">
                    <table >
                        <tr>
                            <th align=right ><label> Identifiant : </label></th>
                            <th><input placeholder="admin" type="text" name="login"/></th>
                        </tr>
                        <tr>
                            <th align=right><label> Mot de passe : </label></th>
                            <th><input placeholder="admin" type="password" name="password"/></th>
                        </tr>
                        <th></br></th>
                        <tr>
                            <th></th>
                            <th>
                            <input type="submit" id="conn_btn" name="action" value="connecter"  />
                            <!--	<input type="submit" id="deco_btn" name="action" value="deconneter" />-->
                            </th>
                        </tr>
                    </table>
                </form>
            </div>
         </div>	
    </body>
</html>

