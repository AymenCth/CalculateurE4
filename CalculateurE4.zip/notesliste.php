<?php
        include_once 'session_check.php';
        include_once 'menu.php';
        

?>
    <div class="container" >
      <h1>Listes des notes</h1>
      <table class="table">
        <thead class="thead-dark">
          
            <th>ID</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Numéro de commission</th>
            <th>Numéro de candidat</th>
            <th>Date de l'épreuve</th>
            <th> Type de l'épreuve </th>
            <th>Note</th>
         </thead>

<?php
      try
      {

        include_once 'bddconnect.php';
   /*      $bdd = new PDO('mysql:host=localhost;dbname=calculateur', 'root', 'root', $pdo_options);*/
         
         
         // On recupere tout le contenu de la table epreuve
      $reponse = $bdd->query('SELECT id, nom, prenom, numero_commission, numero_candidat, date_epreuve, type_epreuve, note FROM epreuve');
      
      // On affiche le resultat
      while ($donnees = $reponse->fetch())
      {
         //On affiche l'id et le nom du epreuve en cours
         echo "</tr>";
         echo "<th> $donnees[id] </th>";
         echo "<th> $donnees[nom] </th>";
         echo "<th> $donnees[prenom] </th>";
         echo "<th> $donnees[numero_commission] </th>";
         echo "<th> $donnees[numero_candidat] </th>";
         echo "<th> $donnees[date_epreuve] </th>";
         echo "<th> $donnees[type_epreuve] </th>";
         echo "<th> $donnees[note] </th>";
         echo "</tr>";
     }
      $reponse->closeCursor();
      }
      catch(Exception $e)
      {
         die('Erreur : '.$e->getMessage());
      }
?>

        </tbody>
      </table>
    </div>
   </body>
</htmml>



