function helloFunction() {
    alert("Hello, World!");
}
function resetdesvariables() {
    NotesParFamille = [0,0,0];
    NoteTotal = 0;

    for (var i = 0; i < 4; i++) 
    {   
        NotesParLigneYParFamilleX[i] = new Array(7);
        for (var j = 0; j < 7; j++) 
        {
            NotesParLigneYParFamilleX[i][j] = 0;
        }
    }
}
function resetall() {
    //alert("resetall");
    resetdesvariables();
    document.getElementById("NoteTotal").setAttribute("value", 0);
    document.getElementById("soustotal".concat(1)).setAttribute("value", 0);
    document.getElementById("soustotal".concat(2)).setAttribute("value", 0);
    document.getElementById("soustotal".concat(3)).setAttribute("value", 0);
}

var NoteTotal = 0;
var NotesParFamille = [0,0,0];
var NotesParLigneYParFamilleX = new Array(4);


function calcnote(){
    var x = arguments[0];//numéro de famille, 1 pour maitrise connaissence, 2 production commentée ...
    var y = arguments[1];//numéro de ligne de la case coché 
    var z = arguments[2];//numéro de colonne de la case coché 
 
    //alert("x:".concat(x,"-y:",y,"-z:",z));
    //alert(x);
    if (z == 1)
    {
       document.getElementById(x.concat(y,2)).checked = false;
       document.getElementById(x.concat(y,3)).checked = false;
       document.getElementById(x.concat(y,4)).checked = false;
       switch(x){
       case "3":
       NotesParLigneYParFamilleX[x][y]=0.75;
        break;
       case "2":
       NotesParLigneYParFamilleX[x][y]=0.50;
        break;
       case "1":
       NotesParLigneYParFamilleX[x][y]=0.75;
       }
    }
    if (z == 2)
    {
       document.getElementById(x.concat(y,1)).checked = false;
       document.getElementById(x.concat(y,3)).checked = false;
       document.getElementById(x.concat(y,4)).checked = false;
       switch(x){
       case "3":
       NotesParLigneYParFamilleX[x][y]=1.50;
        break;
       case "2":
       NotesParLigneYParFamilleX[x][y]=1;
        break;
       case "1":
       NotesParLigneYParFamilleX[x][y]=1.5;
       }
    }
    if (z == 3)
    {
       document.getElementById(x.concat(y,1)).checked = false;
       document.getElementById(x.concat(y,2)).checked = false;
       document.getElementById(x.concat(y,4)).checked = false;
       switch(x){
       case "3":
       NotesParLigneYParFamilleX[x][y]=2.25;
        break;
       case "2":
       NotesParLigneYParFamilleX[x][y]=1.5;
        break;
       case "1":
       NotesParLigneYParFamilleX[x][y]=2.25;
       }
    }
    if (z == 4)
    {
       document.getElementById(x.concat(y,1)).checked = false;
       document.getElementById(x.concat(y,2)).checked = false;
       document.getElementById(x.concat(y,3)).checked = false;
       switch(x){
       case "3":
       NotesParLigneYParFamilleX[x][y]=3;
        break;
       case "2":
       NotesParLigneYParFamilleX[x][y]=2;
        break;
       case "1":
       NotesParLigneYParFamilleX[x][y]=3;
       }
    }
    
    if (!document.getElementById(x.concat(y,z)).checked)
    {
        NotesParLigneYParFamilleX[x][y]=0;
    }
    
    NotesParFamille[x]=0; //reset pour la recalculer
    for (var yy = 0; yy < 7; yy++) 
    {
    NotesParFamille[x] = NotesParLigneYParFamilleX[x][yy] + NotesParFamille[x];
    }
    NoteTotal = NotesParFamille[1]+NotesParFamille[2]+NotesParFamille[3];

    
 
    NoteTotal = Math.round(NoteTotal * 100) / 100;
    NotesParFamille[x] = Math.round(NotesParFamille[x] * 100) / 100;
    document.getElementById("soustotal".concat(x)).setAttribute("value", NotesParFamille[x].toString());
    document.getElementById("NoteTotal").setAttribute("value", NoteTotal.toString());
}

//var note = document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());

