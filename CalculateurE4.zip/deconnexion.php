<?php
session_start();
session_destroy();
$_SESSION["ath_status"] = "deconnecte";
header("location:index.php");

?>

