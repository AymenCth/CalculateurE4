<?php
         $pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
         
         //création de l'objet PDO (connecteur avec la base mysql)
         //Obernai
		 $bdd = new PDO('mysql:host=localhost;dbname=calculateur', 'root', 'root', $pdo_options);
		 //Stras
		 //$bdd = new PDO('mysql:host=localhost;dbname=calculateur;charset=utf8', 'root', '', $pdo_options);


