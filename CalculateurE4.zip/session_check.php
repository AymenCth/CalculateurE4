<?php
	session_start();
	
        /*
        echo "Dump calc post   : ";
	echo var_dump($_POST);
	echo "Dump session: ";
	echo var_dump($_SESSION);
          */
         
	if($_SESSION["ath_status"] != "connecte")
	{
		header("location:connexion.php");
		exit();
	}
?>
