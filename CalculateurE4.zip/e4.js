function helloFunction() {
    alert("Hello, World!");
}

var noteMaitriseConnaissance = 0;

function ligneunecaseune(){
    if(noteMaitriseConnaissance == 0.4)
    {
        noteMaitriseConnaissance = 0;
    }
    else
    {
        noteMaitriseConnaissance = 0.4;
    }

    console.log(noteMaitriseConnaissance);
    document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());
}

var note = document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());



function ligneunecasedeux(){
    if(noteMaitriseConnaissance == 0.8)
    {
        noteMaitriseConnaissance = 0;
    }
    else
    {
        noteMaitriseConnaissance = 0.8;
    }

    console.log(noteMaitriseConnaissance);
    document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());
}

var note = document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());



function ligneunecasetrois(){
    if(noteMaitriseConnaissance == 1.2)
    {
        noteMaitriseConnaissance = 0;
    }
    else
    {
        noteMaitriseConnaissance = 1.2;
    }

    console.log(noteMaitriseConnaissance);
    document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());
}

var note = document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());



function ligneunecasequatre(){
    if(noteMaitriseConnaissance == 1.6)
    {
        noteMaitriseConnaissance = 0;
    }
    else
    {
        noteMaitriseConnaissance = 1.6;
    }

    console.log(noteMaitriseConnaissance);
    document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());
}

var note = document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());



function lignedeuxcaseune(){
    if(noteMaitriseConnaissance == 0.4)
    {
        noteMaitriseConnaissance = 0.8;
    }
    /*if(noteMaitriseConnaissance = 1.2 || 1.6)
    {
        noteMaitriseConnaissance = noteMaitriseConnaissance + 0.4;
    }*/

    console.log(noteMaitriseConnaissance);
    document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());
}

var note = document.getElementById("test").setAttribute("value", noteMaitriseConnaissance.toString());




