<?php
        include_once 'session_check.php';
     include_once 'bddconnect.php';  
     
       echo "Dump post   : ";
  echo @var_dump($_POST);

  $data_form["action"]=$_POST["action_name"];
  
  switch ($data_form["action"]) {
    case "delete_user":
        $data_form["data_id"]=$_POST['data_id'];
        try
      {
        // assemblage de la requête sql.
        $sql ="delete FROM `membre` WHERE `id` = '".$data_form["data_id"]."'";
        // On executer la requête sql
        $reponse = $bdd->exec($sql);
        $_SESSION['Message']= "<label><p style='color:red'>Message : identifiant ".$data_form["data_id"]." bien supprimé. </label>";
      }
      catch(Exception $e)
      {
         die('Erreur : '.$e->getMessage());
      }
        break;
    
    case "add_user":
        try
        {
          $data_form["login"] = $_POST["new_id"];
          $data_form["motdepasse"] =  $_POST["new_password"];
          // on retire les espace
          $data_form["login"] = trim($data_form["login"]);
          $data_form["motdepasse"] = trim($data_form["motdepasse"]);
          if ((strlen($data_form["login"])<3) or (strlen($data_form["motdepasse"]))<3)
             $_SESSION['Message']= "<label><p style='color:red'>Message : login ou mot de passe avec minimum 3 caractères </label>";
          else {
          // assemblage de la requête sql.
          $reponse = $bdd->prepare('SELECT count(id) FROM MEMBRE where identifiant= :identifiant ');
          $reponse->execute(['identifiant' => $data_form["login"]]); 
           // On executer la requête sql
          $donnees = $reponse->fetch();
          if ($donnees["count(id)"] > 0)
              $_SESSION['Message']= "<label><p style='color:red'>Message : identifiant non disponible</label>";
          else{
            $req = $bdd->prepare('INSERT INTO membre (identifiant, motdepasse) VALUES(?, ?)');
            $req->execute(array( $data_form["login"], $data_form["motdepasse"]));   
           $_SESSION['Message']="<label><p style='color:green'> Message : nouvel utilisateur '".$data_form["login"]."' ajouté</label>";
          }            
          
          }
      
        }
        catch(Exception $e)
        {
           $_SESSION['Message']=$e->getMessage();
           die('Erreur : '.$e->getMessage());
        }
        break;
    default:
        break;
    }
    
    header('Location: newuser.php');
      
      ?>