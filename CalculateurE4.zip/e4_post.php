<?php

        include_once 'bddconnect.php';
    // Effectuer ici la requête qui insère le message



    // On ajoute une entrée dans la table calculateur

    $req = $bdd->prepare('INSERT INTO epreuve (nom, prenom, numero_commission, numero_candidat, date_epreuve, type_epreuve, note) VALUES(?, ?, ?, ?, ?, ?, ?)');

    $req->execute(array($_POST['nom'], $_POST['prenom'], $_POST['numero_commission'], $_POST['numero_candidat'], $_POST['date_epreuve'], $_POST['ch'], $_POST['note'])); 

    /*On récupère les valeurs des premières checkbox

    $ch=$_POST["ch"];

    // On les insères dans la table

    $req=$pdo->prepare("insert into type_epreuve (type_epreuve) values (?)");
    $req->execute(array(implode("|", $ch)));*/

	// Puis rediriger vers e4.php comme ceci :

	header('Location: notesliste.php');

?>

