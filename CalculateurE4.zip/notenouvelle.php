<?php
        include_once 'session_check.php';
        include_once 'menu.php';
?>
            <div class="container">
              <div class="row">
                <div class="col">
                  <p><b>E4</b></p>
                </div>
              </div>

          <hr/>    

          <form action="./e4_post.php" method="POST" onload="resetdesvariables()"> 
              <div class="checkbox-group required">
            <div class="row">
              <div class="col-12 col-lg-4">
                  <p>Epreuve ponctuelle <input type="checkbox" name="ch" value="Ponctuelle">
              </div>
              <div class="col-12 col-lg-4">
                  <p>Contrôle en cours de formation <input type="checkbox" name="ch" value="En formation"></p>
              </div>
              <div class="col-12 col-lg-4">
                  <p><input type="reset" onclick="resetall()" value="Tous désélectionner"></p>
              </div>
            </div>
                  </div>   

          <hr/>
            <br>
                    <div class="row">
                      <div class="col-12 col-lg-2">
                          <p>Nom candidat(e) : <input type="text" name="nom" id="nom" required></p>
                      </div>
                      <div class="col-12 col-lg-2">
                          <p>Prénom candidat(e) : <input type="text" name="prenom" id="prenom" required></p>
                      </div>
                      <div class="col-12 col-lg-2">
                          <p>Numéro commission : <input type="number" name="numero_commission" id="numero_commission" required></p>
                      </div>
                      <div class="col-12 col-lg-2">
                          <p>Numéro candidat : <input type="number" name="numero_candidat" id="numero_candidat" required></p>
                      </div>                       
                      <div class="col-12 col-lg-2">
                          <p>Date : <input type="date" class="datepicker" name="date_epreuve" id="date_epreuve" required></p>
                      </div>
                    </div> 
          <hr/>
              <div class="row">
                <div class="col-12 col-lg-4">
                  <p><b>Critères d'évaluation </b> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <b> Très insuffisant </b> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p><b>Insuffisant</b></p>
                </div>
                <div class="col-12 col-lg-2">
                  <p><b>Bien</b></p>
                </div>
                <div class="col-12 col-lg-2">
                  <p><b>Très bien</b></p>
                </div>
            </div>
          <hr/>
              <!--<div class="row">
                <div class="col-12 col-lg-6">
                  <p><b>Maîtrise des connaissances :</b></p>
                </div>
              <div class="col-12 col-lg-2">
                  <p></p>
                </div>
              <div class="col-12 col-lg-4">
                  <p>Note <input id="soustotal1" type="text" name="test" value=""> /8</p></p>
                </div>
              </div>

                <div class="row">
                <div class="col-12 col-lg-4">
                  <p> - </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="111" onchange="calcnote('1','1','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="112" onchange="calcnote('1','1','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="113" onchange="calcnote('1','1','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="114" onchange="calcnote('1','1','4')"> </p>
                </div>
              </div>

              <div class="row">
                <div class="col-12 col-lg-4">
                  <p> - </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="121" onchange="calcnote('1','2','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="122" onchange="calcnote('1','2','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="123" onchange="calcnote('1','2','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="124" onchange="calcnote('1','2','4')"> </p>
                </div>
              </div>


              <div class="row">
                <div class="col-12 col-lg-4">
                  <p> - </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="131" onchange="calcnote('1','3','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="132" onchange="calcnote('1','3','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="133" onchange="calcnote('1','3','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="134" onchange="calcnote('1','3','4')"> </p>
                </div>
              </div>

              <div class="row">
                <div class="col-12 col-lg-4">
                  <p> - </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="141" onchange="calcnote('1','4','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="142" onchange="calcnote('1','4','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="143" onchange="calcnote('1','4','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="144" onchange="calcnote('1','4','4')"> </p>
                </div>
              </div>


              <div class="row">
                <div class="col-12 col-lg-4">
                  <p> - </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="151" onchange="calcnote('1','5','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="152" onchange="calcnote('1','5','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="153" onchange="calcnote('1','5','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="154" onchange="calcnote('1','5','4')"> </p>
                </div>
              </div>


          <hr/>-->


            <div class="row">
                <div class="col-12 col-lg-6">
                  <p><b>Première phase : entretien d’explicitation</b></p>
                </div>

                <div class="col-12 col-lg-2">
                  <p></p>
                </div>


                <div class="col-12 col-lg-4">
                  <p>Note <input id="soustotal2" type="text" name="test" value=""> /8</p></p>
                </div>
            </div>


                <div class="row">
                <div class="col-12 col-lg-4">
                  <p> Interprétation de l’expression des besoins</p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="211" onchange="calcnote('2','1','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="212" onchange="calcnote('2','1','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="213" onchange="calcnote('2','1','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="214" onchange="calcnote('2','1','4')"> </p>
                </div>
              </div>


              <div class="row">
                <div class="col-12 col-lg-4">
                  <p>Adéquation des spécifications techniques proposées</p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="221" onchange="calcnote('2','2','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="222" onchange="calcnote('2','2','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="223" onchange="calcnote('2','2','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="224" onchange="calcnote('2','2','4')"> </p>
                </div>
              </div>


              <div class="row">
                <div class="col-12 col-lg-4">
                  <p>Qualité de la démarche de réalisation envisagée</p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="231" onchange="calcnote('2','3','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="232" onchange="calcnote('2','3','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="233" onchange="calcnote('2','3','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="234" onchange="calcnote('2','3','4')"> </p>
                </div>
              </div>


              <div class="row">
                <div class="col-12 col-lg-4">
                  <p>Prise en compte des observations du jury</p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="241" onchange="calcnote('2','4','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="242" onchange="calcnote('2','4','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="243" onchange="calcnote('2','4','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="244" onchange="calcnote('2','4','4')"> </p>
                </div>
              </div>



              <!--<div class="row">
                <div class="col-12 col-lg-4">
                  <p>Lisibilité de la solution proposée  </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="251" onchange="calcnote('2','5','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="252" onchange="calcnote('2','5','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="253" onchange="calcnote('2','5','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="254" onchange="calcnote('2','5','4')"> </p>
                </div>
              </div>--> 


          <hr/>



            <div class="row">
                <div class="col-12 col-lg-6">
                  <p><b>Deuxième phase : recette de la solution</b></p>
                </div>

                <div class="col-12 col-lg-2">
                  <p></p>
                </div>


                <div class="col-12 col-lg-4">
                  <p>Note <input id="soustotal3" type="text" name="test" value=""> /12</p></p>
                </div>
            </div>


            <div class="row">
                <div class="col-12 col-lg-4">
                  <p>Conformité de la production aux exigences de la demande </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="311" onchange="calcnote('3','1','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="312" onchange="calcnote('3','1','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="313" onchange="calcnote('3','1','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="314" onchange="calcnote('3','1','4')"> </p>
                </div>
              </div>



            <div class="row">
                <div class="col-12 col-lg-4">
                  <p>Justification de la solution</p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="321" onchange="calcnote('3','2','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="322" onchange="calcnote('3','2','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="323" onchange="calcnote('3','2','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="324" onchange="calcnote('3','2','4')"> </p>
                </div>
              </div>



            <div class="row">
                <div class="col-12 col-lg-4">
                  <p>Qualité de la réalisation</p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="331" onchange="calcnote('3','3','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="332" onchange="calcnote('3','3','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="333" onchange="calcnote('3','3','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="334" onchange="calcnote('3','3','4')"> </p>
                </div>
              </div>



            <div class="row">
                <div class="col-12 col-lg-4">
                  <p>Analyse critique de la solution proposée</p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="341" onchange="calcnote('3','4','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="342" onchange="calcnote('3','4','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="343" onchange="calcnote('3','4','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="344" onchange="calcnote('3','4','4')"> </p>
                </div>
              </div>


            <!--<div class="row">
                <div class="col-12 col-lg-4">
                  <p>Adéquation des tests de validation effectués </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="351" onchange="calcnote('3','5','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="352" onchange="calcnote('3','5','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="353" onchange="calcnote('3','5','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="354" onchange="calcnote('3','5','4')"> </p>
                </div>
              </div>


            <div class="row">
                <div class="col-12 col-lg-4">
                  <p>Capacité à proposer des corrections pertinentes  </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="361" onchange="calcnote('3','6','1')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="362" onchange="calcnote('3','6','2')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="363" onchange="calcnote('3','6','3')"> </p>
                </div>
                <div class="col-12 col-lg-2">
                  <p> <input type="checkbox" id="364" onchange="calcnote('3','6','4')"> </p>
                </div>
              </div>--> 


        <hr/>


            <div class="row">
                <div class="col-12 col-lg-6">
                  <p><b>Note globale </b></p>
                </div>

                <div class="col-12 col-lg-2">
                  <p></p>
                </div>


                <div class="col-12 col-lg-4">
                    <p>Note <input type="text" name="note" id="NoteTotal" value="" required> /20</p></p> 
                </div>
            </div>

            <br>

            <div class="row">
                <div class="col-12 col-lg-4">
                  <p></p>
                </div>
                <div class="col-12 col-lg-2">
                  <p></p>
                </div>
                <div class="col-12 col-lg-2">
                  <p></p>
                </div>
                <div class="col-12 col-lg-2">
                  <p></p>
                </div>
                
          <div class="col-12 col-lg-2">
              <input type="submit" value="Valider" /></p>
          </div>
                    
            </div>

        </form>
              <div class="row">
                <div class="col">
                  <p></p> 
                </div>
              </div>
            </div>

            <script src="notecalcul.js"></script>
  </body>
</html>
