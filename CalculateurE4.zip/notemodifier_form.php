<?php
        include_once 'session_check.php';
        include_once 'menu.php';
        include_once 'bddconnect.php';             

?>
    </br>
    <div >
    <h1>Modifier une note</h1>
      <table class="table">
        <thead class="thead-dark">
          <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>N° de commission</th>
            <th>N° de candidat</th>
            <th>Date de l'épreuve</th>
            <th>Type de l'épreuve </th>
            <th>Note</th>
            <th>Action</th>
            <th></th>
         </thead>

<?php
 

      try
      {
        // On recupere tout le contenu de la table Client
      $reponse = $bdd->query('SELECT id, nom, prenom, numero_commission, numero_candidat, date_epreuve, type_epreuve, note FROM epreuve');
      
      // On affiche le resultat
      while ($donnees = $reponse->fetch())
      {
         //On affiche l'id et le nom du client en cours
         echo "</tr>";
         echo '<form id="maj_eleve" method="post" name="maj_eleve"  action="notemodifier_exec.php">';
         echo "<input type= 'hidden' name='action_name' value='update_note'/> ";
         echo "<th>  <input type='text' name='id' value = $donnees[id] readonly> </th>";
         echo "<th>  <input type='text' name='nom' value = $donnees[nom]> </th>";
         echo "<th>  <input type='text' name='prenom' value = $donnees[prenom]> </th>";
         echo "<th>  <input type='text' name='numero_commission' value = $donnees[numero_commission]> </th>";
         echo "<th>  <input type='text' name='numero_candidat' value = $donnees[numero_candidat]> </th>";
         echo "<th>  <input type='text' name='date_epreuve' value = $donnees[date_epreuve]> </th>";
         echo "<th>  <input type='text' name='type_epreuve' value = $donnees[type_epreuve]> </th>";
         echo "<th>  <input type='text' name='note' value = $donnees[note]> </th>";
         echo "<th> <input type='submit'  value='Modifier' id=$donnees[id]>";
         echo '</form>';
         
         echo '<form id="maj_eleve" method="post" name="maj_eleve"  action="notemodifier_exec.php">';
         echo "<input type= 'hidden' name='action_name' value='delete_note'/> ";
         echo "<input type= 'hidden' name='eleve_id' value=$donnees[id]> ";
         echo "<input type='submit'  value='Supprimer' id=$donnees[id]></th>";
         echo '</form>';

         echo "</tr>";
      
         
      }
      $reponse->closeCursor();
      }
      catch(Exception $e)
      {
         die('Erreur : '.$e->getMessage());
      }
      echo" </table>";
    
      if (isset($_SESSION['Message']))
      {
        echo '<div class="text-center">';
        echo  $_SESSION['Message'];
        echo  '</div> ';
        UNSET($_SESSION['Message']);
      }
?>
       </div>   
      </body>
</htmml>

